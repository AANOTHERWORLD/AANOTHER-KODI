import xbmc
import xbmcgui
import xbmcaddon
import urllib.request
import os
import zipfile

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
BUILD_URL = 'https://drive.google.com/uc?export=download&id=YOUR_FILE_ID'  # Replace with your direct download URL
ZIP_PATH = os.path.join(xbmc.translatePath('special://home'), 'aanother-kodi.zip')

def download_build():
    try:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Downloading build...', xbmcgui.NOTIFICATION_INFO, 5000)
        urllib.request.urlretrieve(BUILD_URL, ZIP_PATH)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Download complete.', xbmcgui.NOTIFICATION_INFO, 5000)
        return True
    except Exception as e:
        xbmcgui.Dialog().notification(ADDON_NAME, f'Error: {str(e)}', xbmcgui.NOTIFICATION_ERROR, 5000)
        return False

def install_build():
    try:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Installing build...', xbmcgui.NOTIFICATION_INFO, 5000)
        with zipfile.ZipFile(ZIP_PATH, 'r') as zip_ref:
            zip_ref.extractall(xbmc.translatePath('special://home'))
        xbmcgui.Dialog().notification(ADDON_NAME, 'Installation complete. Please restart Kodi.', xbmcgui.NOTIFICATION_INFO, 5000)
    except Exception as e:
        xbmcgui.Dialog().notification(ADDON_NAME, f'Error: {str(e)}', xbmcgui.NOTIFICATION_ERROR, 5000)

if __name__ == '__main__':
    if download_build():
        install_build()
